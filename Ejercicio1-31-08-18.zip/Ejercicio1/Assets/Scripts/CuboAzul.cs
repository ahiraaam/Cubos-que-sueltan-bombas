﻿using UnityEngine;
using System.Collections;

// Simple Rolling Ball Game code - 18 Oct 2015 Daniel Wood
// Add this code to a script called 'move' and then attach the script to a sphere in your game

[RequireComponent(typeof(Rigidbody))]

public class CuboAzul : MonoBehaviour
{
    public float moveSpeed;
    public int Life = 10;
    
    // Use this for initialization
    void Start()
    {
        moveSpeed = 1f;
    }

    // Update is called once per frame
    void Update()
    {
        

        if (Input.GetKeyDown(KeyCode.Space))
        {
            GameObject bullet = createBullet();

        }

        

        transform.Translate(moveSpeed * Input.GetAxis("Horizontal") * Time.deltaTime, 0f, Input.GetAxis("Vertical") * Time.deltaTime);


        
    }

    void OnTriggerEnter(Collider other) //Lo atraviesa
    {
        if (other.gameObject.name == "BombaRoja")
        {
            this.Life--;
            Debug.Log(Life);

            if (Life == 0)
            {
                Destroy(gameObject);
            }
        }



    }

    private GameObject createBullet()
    {
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere); //me crea una esfera y la guarda en la variable go 
        go.GetComponent<Renderer>().material.color = Color.blue;
        go.transform.position = gameObject.transform.position; // le doy la posicion de la camara
        go.transform.localScale = new Vector3(.5f, .5f, .5f); //tamaño de acuerdo a la camara
        go.AddComponent<Rigidbody>(); //le agregoo el componente rigidbody 
        go.name = "BombaAzul";
        go.GetComponent<Collider>().isTrigger = true;
        go.GetComponent<Rigidbody>().useGravity = false;
        return go; //regreso la esfera y la guardo en la bullet
    }

    void OnGUI()
    {
        GUI.Label(new Rect(10, 0, 100, 20), "Player " + Life);
    }


}
